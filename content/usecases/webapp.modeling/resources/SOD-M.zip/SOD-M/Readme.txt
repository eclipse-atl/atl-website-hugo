This transformation generates a Service Process Model from an Extended Use Case model
in the framework of the SOD-M methodology (see www.kybele.es). 
To customize the transformation for each specific case, an AMW weaving model is used.
This weaving model serves to annotate the Extended Use Case Model.
It contains the "parameters" for each execution of the M2M transformation.

The project contains 2 scenarios: one (Simplified.Models folder) being a reduced version 
of the other (Complete.Models folder). Both of them are defined during the development of 
a Web Information System for conference management. The system offers three services to the
users: Submit an Article, View Submitted Articles and Edit Author Data.
In the former, just one of them is considered: the View Submitted Articles service 

Transformation File
-------------------
 # AnnotatedEUC2ServiceProcess.atl -> the ATL transformation valid for both scenarios
 
 Metamodels Files (Metamodels folder)
 -----------------------------------
 # Metamodels/ExtendedUseCase.ecore (.km3)
 	-> Extended Use Case metamodel based on the UML2.0 Use Case metamodel
 # Metamodels/ServiceProcess.ecore (.km3)
 	-> Service Process metamodel based on the Activity Diagrams UML 2.0 metamodel
 # Metamodels/EUCAnnot_base_extension.km3
 	-> Extension of the core weaving metamodel for annotating Extended Use Case models.
 # Metamodels/AnnotatingEUC.ecore 
 	-> Weaving metamodel obtained from the extension above
 	
Files for Simplified Scenary (Simplified.Models folder)
--------------------------------------------------------
 # Input.xmi -> Input file containing the Extended use Case 
 	model in which just one Service has been included: the View Submitted Articles service
 # AnnotatedEUC.amw  
 	-> Annotation model for the previous model
 # Output.xmi 
 	-> Service Process Model. It is the obtained executing the transformation.

Files for Complete Scenary (Complete.Models folder)
---------------------------------------------------
 # Input.xmi -> Input file containing the Extended Use Case model 
 	in which the three services offered by the system have been included: View Submitted Articles, 
 	Edit Author Data and Submit Article
 # AnnotatedEUC.amw 
 	-> Annotation model for the previous model
 # Output.xmi -> Service Process model obtained as output of the transformation
 	
Build Files
----------- 	
# build.xml	-> ANT project comprising the tasks needed to execute the 
	transformation. They are parameterized in order to support the two 
	possible configurations (Simplified and Complete scenarios)
# build.properties -> The parameters for the build file
	 
